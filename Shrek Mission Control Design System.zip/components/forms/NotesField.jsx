import React from "react";

/**
 * NotesField — labeled textarea matching the source app's field-notes
 * panel. Auto-themed to the navy surface with a brass focus ring.
 */
export function NotesField({ label, hint, value, onChange, placeholder, rows = 8, style, ...rest }) {
  const [focused, setFocused] = React.useState(false);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, ...style }}>
      {label && (
        <label style={{
          font: "var(--font-label)", fontWeight: 600, fontSize: "0.8rem",
          letterSpacing: "var(--track-label)", textTransform: "uppercase",
          color: "var(--text-primary)",
        }}>
          {label}
        </label>
      )}
      {hint && (
        <p style={{ font: "var(--type-meta)", color: "var(--text-muted)", margin: 0 }}>{hint}</p>
      )}
      <textarea
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        rows={rows}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          width: "100%",
          minHeight: 160,
          resize: "vertical",
          padding: "13px 14px",
          borderRadius: "var(--radius-lg)",
          background: "rgba(255,255,255,0.03)",
          color: "var(--text-primary)",
          border: `1px solid ${focused ? "var(--line-brass)" : "var(--border)"}`,
          boxShadow: focused ? "0 0 0 3px rgba(194,161,79,0.15)" : "none",
          font: "var(--type-read)",
          lineHeight: 1.55,
          outline: "none",
          transition: "border-color var(--dur-fast) var(--ease), box-shadow var(--dur-fast) var(--ease)",
        }}
        {...rest}
      />
    </div>
  );
}
