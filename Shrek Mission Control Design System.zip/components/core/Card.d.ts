import React from "react";

export interface CardProps {
  children?: React.ReactNode;
  /** Colored left accent rail, codes the section. @default "none" */
  rail?: "crimson" | "blue" | "gold" | "green" | "amber" | "none";
  /** CSS padding value. @default "var(--space-4)" */
  padding?: string;
  style?: React.CSSProperties;
}

export interface CardSlotProps {
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Primary surface panel with optional accent rail.
 * @startingPoint section="Core" subtitle="Accent-rail content panel" viewport="700x260"
 */
export function Card(props: CardProps): JSX.Element;
export namespace Card {
  function Title(props: CardSlotProps): JSX.Element;
  function Meta(props: CardSlotProps): JSX.Element;
}
