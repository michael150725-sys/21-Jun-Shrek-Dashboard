import React from "react";

const RAILS = {
  crimson: "var(--rail-crimson)",
  blue: "var(--rail-blue)",
  gold: "var(--rail-gold)",
  green: "var(--rail-green)",
  amber: "var(--rail-amber)",
  none: null,
};

/**
 * Card — the primary surface of Mission Control. Large soft radius,
 * deep drop shadow, optional colored left "accent rail" (mirrors the
 * source app's .accent-card::before). Use rail color to code sections.
 */
export function Card({ children, rail = "none", padding = "var(--space-4)", style, ...rest }) {
  const railColor = RAILS[rail];
  return (
    <div
      style={{
        position: "relative",
        overflow: "hidden",
        background:
          "linear-gradient(180deg, rgba(28,47,79,0.55), rgba(11,20,38,0.92))",
        border: "1px solid var(--border)",
        borderRadius: "var(--radius-xl)",
        boxShadow: "var(--shadow-card), var(--shadow-inset)",
        padding,
        ...style,
      }}
      {...rest}
    >
      {railColor && (
        <span
          aria-hidden="true"
          style={{
            position: "absolute",
            top: 0,
            bottom: 0,
            left: 0,
            width: "var(--rail-w)",
            background: railColor,
          }}
        />
      )}
      {children}
    </div>
  );
}

/** Card.Title — Spectral serif heading slot. */
Card.Title = function CardTitle({ children, style, ...rest }) {
  return (
    <h2 style={{ font: "var(--type-h2)", color: "var(--text-primary)", margin: 0, ...style }} {...rest}>
      {children}
    </h2>
  );
};

/** Card.Meta — muted sub-line under a title. */
Card.Meta = function CardMeta({ children, style, ...rest }) {
  return (
    <p style={{ font: "var(--type-meta)", color: "var(--text-muted)", margin: "6px 0 0", ...style }} {...rest}>
      {children}
    </p>
  );
};
