import React from "react";

export interface ArticleCardProps {
  title: string;
  /** Dek / lede line. */
  summary?: string;
  /** Source name, e.g. "POLITICO". */
  source?: string;
  /** Formatted timestamp string. */
  time?: string;
  /** Show a crimson breaking flag. @default false */
  breaking?: boolean;
  href?: string;
  onClick?: (e: React.MouseEvent<HTMLAnchorElement>) => void;
  style?: React.CSSProperties;
}

/**
 * Single clickable feed item with serif headline + mono byline.
 * @startingPoint section="News" subtitle="Feed article item" viewport="700x150"
 */
export function ArticleCard(props: ArticleCardProps): JSX.Element;
