import React from "react";
import { Card } from "../core/Card.jsx";
import { Badge } from "../core/Badge.jsx";
import { ArticleCard } from "./ArticleCard.jsx";

/**
 * SourceTile — a feed column for one outlet (The Hill, POLITICO, …).
 * Big underlined source link, item count, scrollable article stack.
 * Composes Card + Badge + ArticleCard.
 */
export function SourceTile({ source, homepage = "#", items = [], maxItems = 12, style }) {
  const shown = items.slice(0, maxItems);
  return (
    <Card padding="var(--space-4)" style={{ display: "flex", flexDirection: "column", minHeight: 420, ...style }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10, marginBottom: 14 }}>
        <a
          href={homepage}
          target="_blank"
          rel="noreferrer"
          style={{
            font: "var(--font-sans)", fontWeight: 800, fontSize: "1.2rem", lineHeight: 1.15,
            color: "var(--federal-300)",
            textDecoration: "underline", textDecorationThickness: 2, textUnderlineOffset: 4,
          }}
        >
          {source} <span style={{ fontSize: "0.85em" }}>↗</span>
        </a>
        <Badge tone="neutral">{items.length} items</Badge>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, overflowY: "auto", maxHeight: 360, paddingRight: 4 }}>
        {shown.map((it, i) => (
          <ArticleCard key={i} {...it} />
        ))}
        {shown.length === 0 && (
          <div style={{
            padding: "14px", borderRadius: "var(--radius-md)",
            border: "1px dashed var(--border-strong)", background: "rgba(255,255,255,0.015)",
          }}>
            <h4 style={{ font: "var(--type-h3)", fontSize: "0.98rem", color: "var(--text-body)", margin: 0 }}>No current feed items</h4>
            <p style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", margin: "6px 0 0" }}>
              This source returned no recent English-language items.
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}
