Themed textarea for the field-notes / running-assessment panel; auto-saves are wired by the consumer.

```jsx
<NotesField
  label="Field notes"
  hint="Local to this browser. Auto-saves as you type."
  value={notes} onChange={(e) => setNotes(e.target.value)}
  placeholder="Track takeaways, timelines, claims to verify…"
/>
```
