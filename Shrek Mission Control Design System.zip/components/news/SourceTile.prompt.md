A feed column for one news outlet; renders a scrollable stack of ArticleCards with an item count.

```jsx
<SourceTile
  source="The Hill"
  homepage="https://thehill.com"
  items={[{ title: "...", summary: "...", time: "5:10 PM" }]}
/>
```

Drops to an English-only empty state when `items` is empty. Composes Card + Badge + ArticleCard.
