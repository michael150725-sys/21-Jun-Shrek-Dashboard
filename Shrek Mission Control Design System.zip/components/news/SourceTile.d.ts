import React from "react";

export interface SourceFeedItem {
  title: string;
  summary?: string;
  source?: string;
  time?: string;
  breaking?: boolean;
  href?: string;
}

export interface SourceTileProps {
  /** Outlet display name, e.g. "The Hill". */
  source: string;
  homepage?: string;
  items?: SourceFeedItem[];
  /** Max articles shown. @default 12 */
  maxItems?: number;
  style?: React.CSSProperties;
}

/**
 * Per-outlet feed column with scrollable article stack.
 * @startingPoint section="News" subtitle="Per-source feed column" viewport="380x440"
 */
export function SourceTile(props: SourceTileProps): JSX.Element;
