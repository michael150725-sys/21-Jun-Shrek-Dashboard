import React from "react";

/**
 * ArticleCard — a single feed item. Serif headline, muted dek,
 * mono timestamp. Lifts on hover like the source ".article-card".
 */
export function ArticleCard({ title, summary, source, time, breaking = false, href = "#", onClick, style, ...rest }) {
  return (
    <a
      href={href}
      onClick={onClick}
      target="_blank"
      rel="noreferrer"
      style={{
        display: "block",
        padding: "13px 14px",
        borderRadius: "var(--radius-md)",
        border: "1px solid var(--border)",
        background: "rgba(255,255,255,0.018)",
        transition: "transform var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease), background var(--dur-fast) var(--ease)",
        ...style,
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = "translateY(-2px)";
        e.currentTarget.style.borderColor = "var(--line-brass)";
        e.currentTarget.style.background = "rgba(47,111,191,0.06)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "none";
        e.currentTarget.style.borderColor = "var(--border)";
        e.currentTarget.style.background = "rgba(255,255,255,0.018)";
      }}
      {...rest}
    >
      {breaking && (
        <span style={{
          display: "inline-block",
          font: "var(--font-label)", fontSize: "0.66rem", fontWeight: 700,
          letterSpacing: "0.14em", textTransform: "uppercase",
          color: "var(--crimson-300)", marginBottom: 6,
        }}>
          ● Breaking
        </span>
      )}
      <h4 style={{
        font: "var(--type-h3)", fontSize: "1.02rem", lineHeight: 1.3,
        color: "var(--text-primary)", margin: 0,
      }}>
        {title}
      </h4>
      {summary && (
        <p style={{
          font: "var(--type-body-sm)", color: "var(--text-muted)",
          margin: "7px 0 0", lineHeight: 1.45,
        }}>
          {summary}
        </p>
      )}
      {(source || time) && (
        <p style={{
          font: "var(--type-mono-sm)", color: "var(--text-faint)",
          margin: "9px 0 0", letterSpacing: "0.02em",
        }}>
          {source}{source && time ? "  ·  " : ""}{time}
        </p>
      )}
    </a>
  );
}
