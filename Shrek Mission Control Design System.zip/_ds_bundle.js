/* @ds-bundle: {"format":3,"namespace":"ShrekMissionControlDesignSystem_4ccba0","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"NavTab","sourcePath":"components/core/NavTab.jsx"},{"name":"NotesField","sourcePath":"components/forms/NotesField.jsx"},{"name":"ArticleCard","sourcePath":"components/news/ArticleCard.jsx"},{"name":"SourceTile","sourcePath":"components/news/SourceTile.jsx"},{"name":"SummaryPanel","sourcePath":"components/news/SummaryPanel.jsx"},{"name":"TimelineEntry","sourcePath":"components/timeline/TimelineEntry.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"0677b4998a76","components/core/Button.jsx":"69464bd27e40","components/core/Card.jsx":"e06c9c9e571f","components/core/NavTab.jsx":"dfc283e2900e","components/forms/NotesField.jsx":"bf9b0d4fbcdc","components/news/ArticleCard.jsx":"56b6bdde7b47","components/news/SourceTile.jsx":"3e61c36ac343","components/news/SummaryPanel.jsx":"8f08e4339465","components/timeline/TimelineEntry.jsx":"ef41ac85e5ec","ui_kits/mission-control/data.js":"39f3a6b594b9","ui_kits/mission-control/parts.jsx":"dde9363f6d1b","ui_kits/mission-control/screens.jsx":"99fa87444cf6"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ShrekMissionControlDesignSystem_4ccba0 = window.ShrekMissionControlDesignSystem_4ccba0 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — status pill / count chip. Mirrors the source app's
 * ".pill" but extends to the situation-room status colors.
 */
function Badge({
  children,
  tone = "gold",
  solid = false,
  dot = false,
  icon = null,
  style,
  ...rest
}) {
  const tones = {
    gold: {
      fg: "var(--brass-300)",
      bd: "rgba(194,161,79,0.40)",
      bg: "rgba(194,161,79,0.10)",
      solidBg: "var(--brass-500)",
      solidFg: "var(--text-on-brass)"
    },
    blue: {
      fg: "var(--federal-300)",
      bd: "rgba(47,111,191,0.40)",
      bg: "rgba(47,111,191,0.12)",
      solidBg: "var(--federal-500)",
      solidFg: "var(--paper-50)"
    },
    crimson: {
      fg: "var(--crimson-300)",
      bd: "rgba(225,80,104,0.38)",
      bg: "rgba(225,80,104,0.12)",
      solidBg: "var(--crimson-500)",
      solidFg: "var(--paper-50)"
    },
    green: {
      fg: "var(--status-green)",
      bd: "rgba(111,191,139,0.40)",
      bg: "rgba(111,191,139,0.12)",
      solidBg: "var(--status-green)",
      solidFg: "var(--navy-950)"
    },
    amber: {
      fg: "var(--status-amber)",
      bd: "rgba(216,162,74,0.40)",
      bg: "rgba(216,162,74,0.12)",
      solidBg: "var(--status-amber)",
      solidFg: "var(--navy-950)"
    },
    neutral: {
      fg: "var(--text-muted)",
      bd: "var(--line-strong)",
      bg: "rgba(194,204,224,0.06)",
      solidBg: "var(--steel-400)",
      solidFg: "var(--navy-950)"
    }
  }[tone];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "4px 11px",
      borderRadius: "var(--radius-pill)",
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.74rem",
      letterSpacing: "var(--track-label)",
      textTransform: "uppercase",
      color: solid ? tones.solidFg : tones.fg,
      background: solid ? tones.solidBg : tones.bg,
      border: solid ? "1px solid transparent" : `1px solid ${tones.bd}`,
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: solid ? tones.solidFg : tones.fg,
      flex: "none"
    }
  }), icon, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — primary action control for Mission Control.
 * Federal/situation-room styling: crimson primary, navy outline,
 * brass for "official" actions, ghost for low emphasis.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  icon = null,
  iconRight = null,
  disabled = false,
  type = "button",
  onClick,
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "7px 12px",
      font: "var(--type-label)",
      letterSpacing: "var(--track-label)",
      gap: 6,
      radius: "var(--radius-sm)"
    },
    md: {
      padding: "10px 16px",
      font: "var(--type-label)",
      letterSpacing: "var(--track-label)",
      gap: 8,
      radius: "var(--radius-md)"
    },
    lg: {
      padding: "13px 22px",
      font: "var(--type-label)",
      letterSpacing: "var(--track-label)",
      gap: 9,
      radius: "var(--radius-md)"
    }
  }[size];
  const variants = {
    primary: {
      background: "var(--crimson-500)",
      color: "var(--text-on-crimson)",
      border: "1px solid var(--crimson-400)"
    },
    secondary: {
      background: "rgba(47,111,191,0.10)",
      color: "var(--text-primary)",
      border: "1px solid var(--line-strong)"
    },
    gold: {
      background: "var(--brass-500)",
      color: "var(--text-on-brass)",
      border: "1px solid var(--brass-400)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-body)",
      border: "1px solid transparent"
    },
    danger: {
      background: "rgba(225,80,104,0.12)",
      color: "var(--crimson-300)",
      border: "1px solid rgba(225,80,104,0.35)"
    }
  }[variant];
  const fontSize = size === "lg" ? "0.92rem" : size === "sm" ? "0.78rem" : "0.84rem";
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: sizes.gap,
      padding: sizes.padding,
      borderRadius: sizes.radius,
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize,
      letterSpacing: sizes.letterSpacing,
      textTransform: "uppercase",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      whiteSpace: "nowrap",
      transition: "transform var(--dur-fast) var(--ease), filter var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease)",
      ...variants,
      ...style
    },
    onMouseEnter: e => {
      if (!disabled) {
        e.currentTarget.style.transform = "translateY(-1px)";
        e.currentTarget.style.filter = "brightness(1.08)";
      }
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = "none";
      e.currentTarget.style.filter = "none";
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = "translateY(0) scale(0.98)";
    },
    onMouseUp: e => {
      if (!disabled) e.currentTarget.style.transform = "translateY(-1px)";
    }
  }, rest), icon, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const RAILS = {
  crimson: "var(--rail-crimson)",
  blue: "var(--rail-blue)",
  gold: "var(--rail-gold)",
  green: "var(--rail-green)",
  amber: "var(--rail-amber)",
  none: null
};

/**
 * Card — the primary surface of Mission Control. Large soft radius,
 * deep drop shadow, optional colored left "accent rail" (mirrors the
 * source app's .accent-card::before). Use rail color to code sections.
 */
function Card({
  children,
  rail = "none",
  padding = "var(--space-4)",
  style,
  ...rest
}) {
  const railColor = RAILS[rail];
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      overflow: "hidden",
      background: "linear-gradient(180deg, rgba(28,47,79,0.55), rgba(11,20,38,0.92))",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius-xl)",
      boxShadow: "var(--shadow-card), var(--shadow-inset)",
      padding,
      ...style
    }
  }, rest), railColor && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      top: 0,
      bottom: 0,
      left: 0,
      width: "var(--rail-w)",
      background: railColor
    }
  }), children);
}

/** Card.Title — Spectral serif heading slot. */
Card.Title = function CardTitle({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("h2", _extends({
    style: {
      font: "var(--type-h2)",
      color: "var(--text-primary)",
      margin: 0,
      ...style
    }
  }, rest), children);
};

/** Card.Meta — muted sub-line under a title. */
Card.Meta = function CardMeta({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("p", _extends({
    style: {
      font: "var(--type-meta)",
      color: "var(--text-muted)",
      margin: "6px 0 0",
      ...style
    }
  }, rest), children);
};
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/NavTab.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NavTab — pill navigation item used in the top bar.
 * Mirrors the source ".nav a" but adds an active state with a
 * brass underglow for the current view.
 */
function NavTab({
  children,
  icon = null,
  active = false,
  href = "#",
  onClick,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onClick: onClick,
    "aria-current": active ? "page" : undefined,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      padding: "10px 16px",
      borderRadius: "var(--radius-pill)",
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.82rem",
      letterSpacing: "var(--track-label)",
      textTransform: "uppercase",
      color: active ? "var(--paper-50)" : "var(--text-body)",
      background: active ? "rgba(225,80,104,0.16)" : "rgba(47,111,191,0.07)",
      border: active ? "1px solid rgba(225,80,104,0.45)" : "1px solid var(--border)",
      boxShadow: active ? "0 4px 16px rgba(225,80,104,0.20)" : "none",
      cursor: "pointer",
      transition: "border-color var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease), background var(--dur-fast) var(--ease)",
      ...style
    },
    onMouseEnter: e => {
      if (!active) {
        e.currentTarget.style.borderColor = "rgba(47,111,191,0.45)";
        e.currentTarget.style.transform = "translateY(-1px)";
        e.currentTarget.style.background = "rgba(47,111,191,0.14)";
      }
    },
    onMouseLeave: e => {
      if (!active) {
        e.currentTarget.style.borderColor = "var(--border)";
        e.currentTarget.style.transform = "none";
        e.currentTarget.style.background = "rgba(47,111,191,0.07)";
      }
    }
  }, rest), icon, children);
}
Object.assign(__ds_scope, { NavTab });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/NavTab.jsx", error: String((e && e.message) || e) }); }

// components/forms/NotesField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NotesField — labeled textarea matching the source app's field-notes
 * panel. Auto-themed to the navy surface with a brass focus ring.
 */
function NotesField({
  label,
  hint,
  value,
  onChange,
  placeholder,
  rows = 8,
  style,
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.8rem",
      letterSpacing: "var(--track-label)",
      textTransform: "uppercase",
      color: "var(--text-primary)"
    }
  }, label), hint && /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-meta)",
      color: "var(--text-muted)",
      margin: 0
    }
  }, hint), /*#__PURE__*/React.createElement("textarea", _extends({
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    rows: rows,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      width: "100%",
      minHeight: 160,
      resize: "vertical",
      padding: "13px 14px",
      borderRadius: "var(--radius-lg)",
      background: "rgba(255,255,255,0.03)",
      color: "var(--text-primary)",
      border: `1px solid ${focused ? "var(--line-brass)" : "var(--border)"}`,
      boxShadow: focused ? "0 0 0 3px rgba(194,161,79,0.15)" : "none",
      font: "var(--type-read)",
      lineHeight: 1.55,
      outline: "none",
      transition: "border-color var(--dur-fast) var(--ease), box-shadow var(--dur-fast) var(--ease)"
    }
  }, rest)));
}
Object.assign(__ds_scope, { NotesField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/NotesField.jsx", error: String((e && e.message) || e) }); }

// components/news/ArticleCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ArticleCard — a single feed item. Serif headline, muted dek,
 * mono timestamp. Lifts on hover like the source ".article-card".
 */
function ArticleCard({
  title,
  summary,
  source,
  time,
  breaking = false,
  href = "#",
  onClick,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onClick: onClick,
    target: "_blank",
    rel: "noreferrer",
    style: {
      display: "block",
      padding: "13px 14px",
      borderRadius: "var(--radius-md)",
      border: "1px solid var(--border)",
      background: "rgba(255,255,255,0.018)",
      transition: "transform var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease), background var(--dur-fast) var(--ease)",
      ...style
    },
    onMouseEnter: e => {
      e.currentTarget.style.transform = "translateY(-2px)";
      e.currentTarget.style.borderColor = "var(--line-brass)";
      e.currentTarget.style.background = "rgba(47,111,191,0.06)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = "none";
      e.currentTarget.style.borderColor = "var(--border)";
      e.currentTarget.style.background = "rgba(255,255,255,0.018)";
    }
  }, rest), breaking && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      font: "var(--font-label)",
      fontSize: "0.66rem",
      fontWeight: 700,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--crimson-300)",
      marginBottom: 6
    }
  }, "\u25CF Breaking"), /*#__PURE__*/React.createElement("h4", {
    style: {
      font: "var(--type-h3)",
      fontSize: "1.02rem",
      lineHeight: 1.3,
      color: "var(--text-primary)",
      margin: 0
    }
  }, title), summary && /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body-sm)",
      color: "var(--text-muted)",
      margin: "7px 0 0",
      lineHeight: 1.45
    }
  }, summary), (source || time) && /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-mono-sm)",
      color: "var(--text-faint)",
      margin: "9px 0 0",
      letterSpacing: "0.02em"
    }
  }, source, source && time ? "  ·  " : "", time));
}
Object.assign(__ds_scope, { ArticleCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/news/ArticleCard.jsx", error: String((e && e.message) || e) }); }

// components/news/SourceTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SourceTile — a feed column for one outlet (The Hill, POLITICO, …).
 * Big underlined source link, item count, scrollable article stack.
 * Composes Card + Badge + ArticleCard.
 */
function SourceTile({
  source,
  homepage = "#",
  items = [],
  maxItems = 12,
  style
}) {
  const shown = items.slice(0, maxItems);
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    padding: "var(--space-4)",
    style: {
      display: "flex",
      flexDirection: "column",
      minHeight: 420,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      gap: 10,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: homepage,
    target: "_blank",
    rel: "noreferrer",
    style: {
      font: "var(--font-sans)",
      fontWeight: 800,
      fontSize: "1.2rem",
      lineHeight: 1.15,
      color: "var(--federal-300)",
      textDecoration: "underline",
      textDecorationThickness: 2,
      textUnderlineOffset: 4
    }
  }, source, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "0.85em"
    }
  }, "\u2197")), /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "neutral"
  }, items.length, " items")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10,
      overflowY: "auto",
      maxHeight: 360,
      paddingRight: 4
    }
  }, shown.map((it, i) => /*#__PURE__*/React.createElement(__ds_scope.ArticleCard, _extends({
    key: i
  }, it))), shown.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px",
      borderRadius: "var(--radius-md)",
      border: "1px dashed var(--border-strong)",
      background: "rgba(255,255,255,0.015)"
    }
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      font: "var(--type-h3)",
      fontSize: "0.98rem",
      color: "var(--text-body)",
      margin: 0
    }
  }, "No current feed items"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body-sm)",
      color: "var(--text-muted)",
      margin: "6px 0 0"
    }
  }, "This source returned no recent English-language items."))));
}
Object.assign(__ds_scope, { SourceTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/news/SourceTile.jsx", error: String((e && e.message) || e) }); }

// components/news/SummaryPanel.jsx
try { (() => {
/**
 * SummaryPanel — the rollup / briefing panel. Eyebrow label, serif
 * title, a body block of prose, and a footer line with source count
 * and last-updated stamp.
 */
function SummaryPanel({
  eyebrow = "Briefing",
  title,
  rail = "blue",
  basedOn,
  updated,
  status,
  action = null,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    rail: rail,
    padding: "var(--space-5)",
    style: style
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      gap: 16,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.74rem",
      letterSpacing: "var(--track-eyebrow)",
      textTransform: "uppercase",
      color: "var(--eyebrow)",
      margin: "0 0 8px"
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--type-h2)",
      color: "var(--text-primary)",
      margin: 0
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      flex: "none"
    }
  }, status && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "green",
    dot: true
  }, status), action)), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-read)",
      color: "var(--text-body)",
      lineHeight: 1.62,
      whiteSpace: "pre-wrap",
      minHeight: 120
    }
  }, children), (basedOn != null || updated) && /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-mono-sm)",
      color: "var(--text-faint)",
      margin: "14px 0 0",
      letterSpacing: "0.02em"
    }
  }, basedOn != null ? `Based on ${basedOn} articles` : "", basedOn != null && updated ? "   ·   " : "", updated ? `Updated ${updated}` : ""));
}
Object.assign(__ds_scope, { SummaryPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/news/SummaryPanel.jsx", error: String((e && e.message) || e) }); }

// components/timeline/TimelineEntry.jsx
try { (() => {
const ACCENTS = {
  crimson: "var(--crimson-500)",
  amber: "var(--status-amber)",
  blue: "var(--federal-500)",
  gold: "var(--brass-500)",
  green: "var(--status-green)"
};

/**
 * TimelineEntry — one row in a government-timeline board. Shows a label,
 * a date/context detail, a big mono figure (days), and a thin progress
 * track. Use mode="elapsed" for ongoing events (bar grows) and
 * mode="countdown" for future dates (bar shows time remaining).
 * Deterministic: pass the computed value + pct; compute dates upstream.
 */
function TimelineEntry({
  label,
  detail,
  value,
  unit,
  mode = "elapsed",
  pct = 100,
  accent = "crimson",
  status,
  style
}) {
  const color = ACCENTS[accent] || ACCENTS.crimson;
  const width = Math.max(2, Math.min(100, pct));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 9,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-h3)",
      fontSize: "1.04rem",
      color: "var(--text-primary)",
      lineHeight: 1.25
    }
  }, label), status && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.62rem",
      letterSpacing: "0.12em",
      textTransform: "uppercase",
      color
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: color,
      boxShadow: `0 0 0 3px color-mix(in srgb, ${color} 22%, transparent)`
    }
  }), status)), detail && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--type-mono-sm)",
      color: "var(--text-faint)",
      marginTop: 4,
      letterSpacing: "0.02em"
    }
  }, detail)), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "right",
      flex: "none",
      display: "flex",
      alignItems: "baseline",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--font-mono)",
      fontWeight: 600,
      fontSize: "1.5rem",
      color,
      letterSpacing: "0.01em"
    }
  }, typeof value === "number" ? value.toLocaleString() : value), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.72rem",
      letterSpacing: "var(--track-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, unit || (mode === "countdown" ? "days left" : "days")))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      borderRadius: "var(--radius-pill)",
      background: "rgba(255,255,255,0.06)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      width: `${width}%`,
      borderRadius: "var(--radius-pill)",
      background: mode === "countdown" ? `repeating-linear-gradient(90deg, ${color} 0 7px, rgba(255,255,255,0.18) 7px 9px)` : color,
      opacity: mode === "countdown" ? 0.85 : 1
    }
  })));
}
Object.assign(__ds_scope, { TimelineEntry });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/timeline/TimelineEntry.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mission-control/data.js
try { (() => {
/* Sample feed data for the Mission Control UI kit.
   All content is ENGLISH ONLY — the live app filters out
   non-English (e.g. Spanish) items upstream. */
window.MC_DATA = {
  updated: "6:45 PM EDT",
  rollup24: "The Senate advanced the defense authorization overnight on a bipartisan 68\u201330 vote, clearing the bill for a House conference next week. The White House briefed allies ahead of a regional security call, while House leaders scheduled an appropriations hearing before the recess. Markets steadied after the Treasury signaled no change to the auction calendar.",
  rollupIran24: "Diplomats described back-channel talks as \u201cexploratory but serious,\u201d with sanctions relief and inspection access the central sticking points. The State Department reiterated that deterrence posture is unchanged. Allied governments coordinated messaging ahead of tomorrow\u2019s security call.",
  rollupIran6: "A regional security call is being scheduled for the morning. Officials describe the agenda as deconfliction and deterrence. No new force-posture changes have been announced in the last six hours.",
  sources: [{
    id: "politico",
    name: "POLITICO",
    homepage: "https://www.politico.com",
    items: [{
      title: "Senate advances defense package after late-night vote",
      summary: "The 68\u201330 tally clears the bill for a House conference next week.",
      time: "6:42 PM EDT",
      breaking: true
    }, {
      title: "Leadership eyes stopgap to avoid shutdown before recess",
      summary: "Appropriators float a short continuing resolution as talks stall.",
      time: "5:30 PM EDT"
    }, {
      title: "Campaign committees post record second-quarter haul",
      summary: "Both parties report strong small-dollar momentum heading into summer.",
      time: "3:11 PM EDT"
    }]
  }, {
    id: "the-hill",
    name: "The Hill",
    homepage: "https://thehill.com",
    items: [{
      title: "House panel sets hearing on appropriations deadline",
      summary: "Chair signals a stopgap is on the table before the recess.",
      time: "4:05 PM EDT"
    }, {
      title: "Bipartisan group unveils permitting compromise",
      summary: "The framework pairs transmission siting with review timelines.",
      time: "1:48 PM EDT"
    }, {
      title: "Governors press Washington on disaster funding",
      summary: "A coalition warns the relief account could run dry by August.",
      time: "11:20 AM EDT"
    }]
  }, {
    id: "reuters",
    name: "Reuters",
    homepage: "https://www.reuters.com",
    items: [{
      title: "White House briefs allies ahead of regional security call",
      summary: "Officials describe the agenda as deconfliction and deterrence.",
      time: "5:18 PM EDT",
      breaking: true
    }, {
      title: "Treasury holds auction calendar steady, easing markets",
      summary: "No change to issuance sizes despite rate-path speculation.",
      time: "2:55 PM EDT"
    }]
  }, {
    id: "ap-news",
    name: "AP News",
    homepage: "https://apnews.com",
    items: [{
      title: "Supreme Court clears final opinions of the term",
      summary: "Rulings on agency authority and elections close out the session.",
      time: "10:02 AM EDT"
    }, {
      title: "Election officials brief on certification timelines",
      summary: "Briefing emphasizes routine procedures and security protocols.",
      time: "9:14 AM EDT"
    }]
  }, {
    id: "npr",
    name: "NPR",
    homepage: "https://www.npr.org",
    items: [{
      title: "Federal workforce survey shows hiring backlog easing",
      summary: "Agencies report shorter time-to-hire after process changes.",
      time: "12:36 PM EDT"
    }, {
      title: "Inflation cools for a third straight month",
      summary: "Core readings track closer to the central bank\u2019s target.",
      time: "8:30 AM EDT"
    }]
  }, {
    id: "abc-news",
    name: "ABC News",
    homepage: "https://abcnews.go.com",
    items: [{
      title: "Border security funding talks resume on the Hill",
      summary: "Negotiators return to the table after a two-week pause.",
      time: "1:05 PM EDT"
    }]
  }],
  social: [{
    id: "politico",
    name: "POLITICO",
    homepage: "https://www.politico.com",
    note: "Fast political desk; strong on Congress and campaigns.",
    platforms: ["X", "Facebook", "Instagram", "YouTube"]
  }, {
    id: "the-hill",
    name: "The Hill",
    homepage: "https://thehill.com",
    note: "Capitol Hill coverage and floor activity.",
    platforms: ["X", "Facebook", "Instagram", "YouTube"]
  }, {
    id: "reuters",
    name: "Reuters",
    homepage: "https://www.reuters.com",
    note: "Global wire; reliable for breaking confirmations.",
    platforms: ["X", "Facebook", "Instagram", "YouTube", "TikTok"]
  }, {
    id: "ap-news",
    name: "AP News",
    homepage: "https://apnews.com",
    note: "Wire service; primary-source standard.",
    platforms: ["X", "Facebook", "Instagram", "YouTube", "TikTok"]
  }, {
    id: "npr",
    name: "NPR",
    homepage: "https://www.npr.org",
    note: "Public-radio newsroom; explainers and analysis.",
    platforms: ["X", "Facebook", "Instagram", "YouTube", "TikTok"]
  }, {
    id: "nbc-news",
    name: "NBC News",
    homepage: "https://www.nbcnews.com",
    note: "Broadcast network desk; video-forward.",
    platforms: ["X", "Facebook", "Instagram", "YouTube", "TikTok"]
  }],
  // Sample dates — edit these to track real events.
  timelines: {
    conflicts: [{
      label: "Russia\u2013Ukraine war",
      start: "2022-02-24",
      accent: "crimson",
      note: "Ongoing since",
      active: true
    }, {
      label: "Israel\u2013Hamas war",
      start: "2023-10-07",
      accent: "amber",
      note: "Ongoing since",
      active: true
    }, {
      label: "U.S.\u2013Iran war",
      start: "2026-02-28",
      accent: "gold",
      note: "Hostilities since",
      active: true
    }],
    countdowns: [{
      label: "Supreme Court term ends",
      target: "2026-06-29",
      accent: "gold",
      note: "Final opinions"
    }, {
      label: "Debt-ceiling X-date",
      target: "2026-08-01",
      accent: "crimson",
      note: "Borrowing limit reached"
    }, {
      label: "Government funding deadline",
      target: "2026-09-30",
      accent: "amber",
      note: "Funding lapses"
    }, {
      label: "Next Supreme Court term opens",
      target: "2026-10-05",
      accent: "blue",
      note: "First Monday"
    }, {
      label: "U.S. midterm elections",
      target: "2026-11-03",
      accent: "blue",
      note: "Election Day"
    }, {
      label: "Next presidential election",
      target: "2028-11-07",
      accent: "green",
      note: "Election Day"
    }]
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mission-control/data.js", error: String((e && e.message) || e) }); }

// ui_kits/mission-control/parts.jsx
try { (() => {
/* TopBar + shared helpers for the Mission Control UI kit. */

// Lucide icon helper → returns a React element wrapping an <svg>.
function Icon({
  name,
  size = 16,
  color
}) {
  return React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      color
    },
    ref: el => {
      if (!el || !window.lucide || !lucide[name]) return;
      el.innerHTML = "";
      const svg = lucide.createElement(lucide[name]);
      svg.setAttribute("width", size);
      svg.setAttribute("height", size);
      el.appendChild(svg);
    }
  });
}
function LiveClock() {
  const [now, setNow] = React.useState(new Date());
  React.useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const time = now.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
  return /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--font-mono)",
      fontWeight: 500,
      fontSize: "0.82rem",
      color: "var(--text-body)",
      letterSpacing: "0.04em"
    }
  }, time);
}
function TopBar({
  view,
  setView
}) {
  const {
    Badge,
    NavTab
  } = window.ShrekMissionControlDesignSystem_4ccba0;
  const tabs = [{
    id: "dashboard",
    label: "Dashboard",
    icon: "Newspaper"
  }, {
    id: "iran",
    label: "U.S./Iran",
    icon: "Radar"
  }, {
    id: "timelines",
    label: "Timelines",
    icon: "CalendarClock"
  }, {
    id: "social",
    label: "Social Media",
    icon: "ScrollText"
  }];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 20,
      padding: "14px 0 18px",
      borderBottom: "1px solid var(--border)",
      marginBottom: 22,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: "50%",
      flex: "none",
      border: "2px solid var(--brass-500)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      boxShadow: "inset 0 0 0 4px rgba(194,161,79,0.12)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--font-label)",
      fontWeight: 700,
      color: "var(--brass-400)",
      fontSize: "1.4rem"
    }
  }, "\u2605")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.74rem",
      letterSpacing: "var(--track-eyebrow)",
      textTransform: "uppercase",
      color: "var(--eyebrow)"
    }
  }, "Live intelligence monitoring"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "4px 0 0",
      font: "var(--type-h1)",
      color: "var(--text-primary)",
      letterSpacing: "0.01em"
    }
  }, "Shrek's Mission Control"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-end",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "green",
    dot: true
  }, "Operational"), /*#__PURE__*/React.createElement(LiveClock, null)), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 10
    }
  }, tabs.map(t => /*#__PURE__*/React.createElement(NavTab, {
    key: t.id,
    active: view === t.id,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: t.icon,
      size: 15
    }),
    onClick: e => {
      e.preventDefault();
      setView(t.id);
    }
  }, t.label)))));
}
Object.assign(window, {
  Icon,
  LiveClock,
  TopBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mission-control/parts.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mission-control/screens.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The three Mission Control screens. */

function DashboardScreen() {
  const {
    Card,
    Badge,
    SummaryPanel,
    SourceTile,
    Button
  } = window.ShrekMissionControlDesignSystem_4ccba0;
  const d = window.MC_DATA;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.2fr 1fr",
      gap: 18
    },
    className: "mc-grid-main"
  }, /*#__PURE__*/React.createElement(SummaryPanel, {
    eyebrow: "24-hour rollup",
    title: "U.S. politics & world events",
    rail: "blue",
    status: "Operational",
    basedOn: 142,
    updated: d.updated,
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary",
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "RefreshCcw",
        size: 14
      })
    }, "Refresh")
  }, d.rollup24), /*#__PURE__*/React.createElement(Card, {
    rail: "green",
    padding: "var(--space-5)"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--type-h2)",
      color: "var(--text-primary)",
      margin: 0
    }
  }, "Feed status"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-meta)",
      color: "var(--text-muted)",
      margin: "8px 0 16px",
      lineHeight: 1.5
    }
  }, "Server-side feed fetching keeps the browser clear of cross-site blocking. Non-English items are filtered out before they reach the board."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "gold"
  }, "142 articles \xB7 24h"), /*#__PURE__*/React.createElement(Badge, {
    tone: "blue"
  }, "English only")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--type-h3)",
      color: "var(--text-primary)",
      margin: "0 0 6px"
    }
  }, "Included sources"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body-sm)",
      color: "var(--text-muted)",
      margin: 0,
      lineHeight: 1.5
    }
  }, "The Hill, ABC News, NBC News, NPR, Reuters, AP News, POLITICO.")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--type-h3)",
      color: "var(--text-primary)",
      margin: "0 0 6px"
    }
  }, "Refresh cadence"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body-sm)",
      color: "var(--text-muted)",
      margin: 0,
      lineHeight: 1.5
    }
  }, "Automatic refresh every 15 minutes. Use the button above to refresh immediately."))))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(290px, 1fr))",
      gap: 16
    }
  }, d.sources.map(s => /*#__PURE__*/React.createElement(SourceTile, {
    key: s.id,
    source: s.name,
    homepage: s.homepage,
    items: s.items.map(it => ({
      ...it,
      source: s.name
    }))
  }))));
}
function IranScreen() {
  const {
    Card,
    SummaryPanel,
    ArticleCard,
    NotesField,
    Button
  } = window.ShrekMissionControlDesignSystem_4ccba0;
  const d = window.MC_DATA;
  const [notes, setNotes] = React.useState("");
  React.useEffect(() => {
    const saved = window.localStorage.getItem("mc-kit-iran-notes");
    if (saved) setNotes(saved);
  }, []);
  const onChange = e => {
    setNotes(e.target.value);
    window.localStorage.setItem("mc-kit-iran-notes", e.target.value);
  };
  const dailyItems = [d.sources[2].items[0], d.sources[0].items[0]].map((it, i) => ({
    ...it,
    source: i === 0 ? "Reuters" : "POLITICO"
  }));
  const sixItems = [d.sources[2].items[0]].map(it => ({
    ...it,
    source: "Reuters"
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 18,
      alignItems: "stretch",
      flexWrap: "wrap"
    },
    className: "mc-iran-row"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 320,
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(SummaryPanel, {
    eyebrow: "Daily rollup",
    title: "U.S. / Iran",
    rail: "crimson",
    basedOn: 38,
    updated: d.updated
  }, d.rollupIran24), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, dailyItems.map((it, i) => /*#__PURE__*/React.createElement(ArticleCard, _extends({
    key: i
  }, it)))), /*#__PURE__*/React.createElement(SummaryPanel, {
    eyebrow: "Last 6 hours",
    title: "Latest movement",
    rail: "amber",
    basedOn: 6,
    updated: d.updated
  }, d.rollupIran6), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, sixItems.map((it, i) => /*#__PURE__*/React.createElement(ArticleCard, _extends({
    key: i
  }, it))))), /*#__PURE__*/React.createElement("aside", {
    style: {
      width: "min(420px, 100%)"
    }
  }, /*#__PURE__*/React.createElement(Card, {
    rail: "gold",
    padding: "var(--space-5)"
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--type-h2)",
      color: "var(--text-primary)",
      margin: "0 0 4px"
    }
  }, "Field notes"), /*#__PURE__*/React.createElement(NotesField, {
    hint: "Local to this browser. Auto-saves as you type.",
    value: notes,
    onChange: onChange,
    rows: 12,
    placeholder: "Track takeaways, timelines, players, claims to verify, and what feels like signal vs. noise."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginTop: 12,
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "secondary"
  }, "Save notes now"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "danger",
    onClick: () => {
      setNotes("");
      window.localStorage.removeItem("mc-kit-iran-notes");
    }
  }, "Clear notes")))));
}
function SocialScreen() {
  const {
    Card,
    Badge
  } = window.ShrekMissionControlDesignSystem_4ccba0;
  const d = window.MC_DATA;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Card, {
    rail: "crimson",
    padding: "var(--space-5)"
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 8px",
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.74rem",
      letterSpacing: "var(--track-eyebrow)",
      textTransform: "uppercase",
      color: "var(--eyebrow)"
    }
  }, "Launch pad"), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--type-h2)",
      color: "var(--text-primary)",
      margin: 0
    }
  }, "Social media watch floor"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-meta)",
      color: "var(--text-muted)",
      margin: "8px 0 0",
      lineHeight: 1.55,
      maxWidth: "78ch"
    }
  }, "Official source accounts across X, Facebook, Instagram, YouTube, and TikTok. Real-time ingestion needs official APIs or a paid aggregator \u2014 this board keeps the launch links ready.")), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
      gap: 16
    }
  }, d.social.map(s => /*#__PURE__*/React.createElement(Card, {
    key: s.id,
    padding: "var(--space-4)",
    style: {
      minHeight: 220,
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: s.homepage,
    target: "_blank",
    rel: "noreferrer",
    style: {
      font: "var(--font-sans)",
      fontWeight: 800,
      fontSize: "1.15rem",
      color: "var(--federal-300)",
      textDecoration: "underline",
      textDecorationThickness: 2,
      textUnderlineOffset: 4
    }
  }, s.name, " \u2197"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body-sm)",
      color: "var(--text-muted)",
      margin: "10px 0 14px",
      lineHeight: 1.45,
      flex: 1
    }
  }, s.note), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 10
    }
  }, s.platforms.map(p => /*#__PURE__*/React.createElement("a", {
    key: p,
    href: s.homepage,
    target: "_blank",
    rel: "noreferrer",
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: 44,
      borderRadius: "var(--radius-md)",
      border: "1px solid var(--border)",
      background: "rgba(255,255,255,0.03)",
      color: "var(--text-body)",
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.78rem",
      letterSpacing: "0.06em",
      textTransform: "uppercase"
    }
  }, p)))))));
}
function TimelinesScreen() {
  const {
    Card,
    TimelineEntry,
    Badge
  } = window.ShrekMissionControlDesignSystem_4ccba0;
  const d = window.MC_DATA;
  const DAY = 86400000;
  const now = Date.now();
  const fmt = iso => new Date(iso + "T00:00:00").toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
  const daysSince = iso => Math.max(0, Math.floor((now - new Date(iso + "T00:00:00").getTime()) / DAY));
  const daysUntil = iso => Math.max(0, Math.ceil((new Date(iso + "T00:00:00").getTime() - now) / DAY));
  const conflicts = d.timelines.conflicts.map(c => ({
    ...c,
    days: daysSince(c.start)
  }));
  const maxConf = Math.max(...conflicts.map(c => c.days), 1);
  const counts = d.timelines.countdowns.map(c => ({
    ...c,
    days: daysUntil(c.target)
  }));
  const maxCount = Math.max(...counts.map(c => c.days), 1);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Card, {
    rail: "gold",
    padding: "var(--space-5)"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      gap: 16,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 8px",
      font: "var(--font-label)",
      fontWeight: 600,
      fontSize: "0.74rem",
      letterSpacing: "var(--track-eyebrow)",
      textTransform: "uppercase",
      color: "var(--eyebrow)"
    }
  }, "Government timelines"), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--type-h2)",
      color: "var(--text-primary)",
      margin: 0
    }
  }, "How long, and how soon"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-meta)",
      color: "var(--text-muted)",
      margin: "8px 0 0",
      maxWidth: "70ch",
      lineHeight: 1.55
    }
  }, "Live day counts for ongoing events and upcoming deadlines. Counts recompute against today's date.")), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, "Sample dates \xB7 editable"))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(360px, 1fr))",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Card, {
    rail: "crimson",
    padding: "var(--space-5)"
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--type-h3)",
      color: "var(--text-primary)",
      margin: "0 0 4px"
    }
  }, "Active conflicts"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-meta)",
      color: "var(--text-muted)",
      margin: "0 0 20px"
    }
  }, "Elapsed duration"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 22
    }
  }, conflicts.map((c, i) => /*#__PURE__*/React.createElement(TimelineEntry, {
    key: i,
    label: c.label,
    detail: `${c.note} ${fmt(c.start)}`,
    value: c.days,
    mode: "elapsed",
    pct: c.days / maxConf * 100,
    accent: c.accent,
    status: c.active === false ? "Ended" : "Active"
  })))), /*#__PURE__*/React.createElement(Card, {
    rail: "blue",
    padding: "var(--space-5)"
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--type-h3)",
      color: "var(--text-primary)",
      margin: "0 0 4px"
    }
  }, "Countdowns"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-meta)",
      color: "var(--text-muted)",
      margin: "0 0 20px"
    }
  }, "Time remaining"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 22
    }
  }, counts.map((c, i) => /*#__PURE__*/React.createElement(TimelineEntry, {
    key: i,
    label: c.label,
    detail: `${c.note} · ${fmt(c.target)}`,
    value: c.days,
    unit: "days left",
    mode: "countdown",
    pct: c.days / maxCount * 100,
    accent: c.accent
  }))))));
}
Object.assign(window, {
  DashboardScreen,
  IranScreen,
  SocialScreen,
  TimelinesScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mission-control/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.NavTab = __ds_scope.NavTab;

__ds_ns.NotesField = __ds_scope.NotesField;

__ds_ns.ArticleCard = __ds_scope.ArticleCard;

__ds_ns.SourceTile = __ds_scope.SourceTile;

__ds_ns.SummaryPanel = __ds_scope.SummaryPanel;

__ds_ns.TimelineEntry = __ds_scope.TimelineEntry;

})();
