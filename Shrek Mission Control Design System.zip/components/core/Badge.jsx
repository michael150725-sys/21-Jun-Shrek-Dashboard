import React from "react";

/**
 * Badge — status pill / count chip. Mirrors the source app's
 * ".pill" but extends to the situation-room status colors.
 */
export function Badge({ children, tone = "gold", solid = false, dot = false, icon = null, style, ...rest }) {
  const tones = {
    gold:   { fg: "var(--brass-300)",  bd: "rgba(194,161,79,0.40)",  bg: "rgba(194,161,79,0.10)",  solidBg: "var(--brass-500)",   solidFg: "var(--text-on-brass)" },
    blue:   { fg: "var(--federal-300)",bd: "rgba(47,111,191,0.40)",  bg: "rgba(47,111,191,0.12)",  solidBg: "var(--federal-500)", solidFg: "var(--paper-50)" },
    crimson:{ fg: "var(--crimson-300)",bd: "rgba(225,80,104,0.38)",  bg: "rgba(225,80,104,0.12)",  solidBg: "var(--crimson-500)", solidFg: "var(--paper-50)" },
    green:  { fg: "var(--status-green)",bd:"rgba(111,191,139,0.40)", bg: "rgba(111,191,139,0.12)", solidBg: "var(--status-green)",solidFg: "var(--navy-950)" },
    amber:  { fg: "var(--status-amber)",bd:"rgba(216,162,74,0.40)",  bg: "rgba(216,162,74,0.12)",  solidBg: "var(--status-amber)",solidFg: "var(--navy-950)" },
    neutral:{ fg: "var(--text-muted)", bd: "var(--line-strong)",     bg: "rgba(194,204,224,0.06)", solidBg: "var(--steel-400)",   solidFg: "var(--navy-950)" },
  }[tone];

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "4px 11px",
        borderRadius: "var(--radius-pill)",
        font: "var(--font-label)",
        fontWeight: 600,
        fontSize: "0.74rem",
        letterSpacing: "var(--track-label)",
        textTransform: "uppercase",
        color: solid ? tones.solidFg : tones.fg,
        background: solid ? tones.solidBg : tones.bg,
        border: solid ? "1px solid transparent" : `1px solid ${tones.bd}`,
        whiteSpace: "nowrap",
        ...style,
      }}
      {...rest}
    >
      {dot && (
        <span style={{ width: 7, height: 7, borderRadius: "50%", background: solid ? tones.solidFg : tones.fg, flex: "none" }} />
      )}
      {icon}
      {children}
    </span>
  );
}
