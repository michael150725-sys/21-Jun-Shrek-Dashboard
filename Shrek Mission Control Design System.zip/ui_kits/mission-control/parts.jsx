/* TopBar + shared helpers for the Mission Control UI kit. */

// Lucide icon helper → returns a React element wrapping an <svg>.
function Icon({ name, size = 16, color }) {
  return React.createElement("span", {
    style: { display: "inline-flex", alignItems: "center", color },
    ref: (el) => {
      if (!el || !window.lucide || !lucide[name]) return;
      el.innerHTML = "";
      const svg = lucide.createElement(lucide[name]);
      svg.setAttribute("width", size);
      svg.setAttribute("height", size);
      el.appendChild(svg);
    },
  });
}

function LiveClock() {
  const [now, setNow] = React.useState(new Date());
  React.useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  return (
    <span style={{ font: "var(--font-mono)", fontWeight: 500, fontSize: "0.82rem", color: "var(--text-body)", letterSpacing: "0.04em" }}>
      {time}
    </span>
  );
}

function TopBar({ view, setView }) {
  const { Badge, NavTab } = window.ShrekMissionControlDesignSystem_4ccba0;
  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: "Newspaper" },
    { id: "iran", label: "U.S./Iran", icon: "Radar" },
    { id: "timelines", label: "Timelines", icon: "CalendarClock" },
    { id: "social", label: "Social Media", icon: "ScrollText" },
  ];
  return (
    <header style={{
      display: "flex", alignItems: "flex-end", justifyContent: "space-between",
      gap: 20, padding: "14px 0 18px", borderBottom: "1px solid var(--border)", marginBottom: 22,
      flexWrap: "wrap",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
        <div style={{
          width: 52, height: 52, borderRadius: "50%", flex: "none",
          border: "2px solid var(--brass-500)", display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "inset 0 0 0 4px rgba(194,161,79,0.12)",
        }}>
          <span style={{ font: "var(--font-label)", fontWeight: 700, color: "var(--brass-400)", fontSize: "1.4rem" }}>★</span>
        </div>
        <div>
          <p style={{
            margin: 0, font: "var(--font-label)", fontWeight: 600, fontSize: "0.74rem",
            letterSpacing: "var(--track-eyebrow)", textTransform: "uppercase", color: "var(--eyebrow)",
          }}>
            Live intelligence monitoring
          </p>
          <h1 style={{ margin: "4px 0 0", font: "var(--type-h1)", color: "var(--text-primary)", letterSpacing: "0.01em" }}>
            Shrek&apos;s Mission Control
          </h1>
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Badge tone="green" dot>Operational</Badge>
          <LiveClock />
        </div>
        <nav style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
          {tabs.map((t) => (
            <NavTab key={t.id} active={view === t.id} icon={<Icon name={t.icon} size={15} />}
              onClick={(e) => { e.preventDefault(); setView(t.id); }}>
              {t.label}
            </NavTab>
          ))}
        </nav>
      </div>
    </header>
  );
}

Object.assign(window, { Icon, LiveClock, TopBar });
