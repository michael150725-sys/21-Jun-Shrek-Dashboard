# Shrek's Mission Control — Design System

A design system for **Shrek's Mission Control** — a personal, intelligence-style
news dashboard that pulls curated live feeds (The Hill, ABC, NBC, NPR, Reuters,
AP, POLITICO) into one screen so Shrek can monitor U.S. politics and world events
and report them to his followers. It includes a 24-hour rollup, a dedicated
U.S./Iran board with a field-notes panel, and a social-media launch floor.

This system reworks the product's original navy/cyan "sci-fi console" look into a
**political / federal situation-room** identity: deep navy, political crimson,
federal blue, brass/gold, and parchment — red, white & blue with an official seal
accent.

> **Content rule (per product owner):** the feed is **English only**. Non-English
> items (e.g. Spanish-language articles) are filtered out upstream and never reach
> the board. All sample content in this system is written in English.

## Sources

- **GitHub (input):** `michael150725-sys/Shrek-Mission-Control---Web-Version`
  → https://github.com/michael150725-sys/Shrek-Mission-Control---Web-Version
  (Next.js app: `app/`, `components/NewsDashboard.tsx`, `IranBoard.tsx`,
  `SocialBoard.tsx`, `lib/sources.ts`, `app/globals.css`.)
  Explore this repo further to build more accurate Mission Control screens.

The original app used system **Arial** only and **Lucide** icons (`lucide-react`).
No bespoke logo or imagery shipped in the repo.

---

## Content fundamentals

**Voice.** Calm, declarative, operator-grade. Reads like a briefing desk, not a
blog. Short, factual sentences; active voice; no hype. Occasional dry wit is
on-brand (the source app jokes about "tiny web goblins") but it stays rare and
never undercuts the facts.

- **Person:** Mostly impersonal/system voice ("The dashboard is using…",
  "Based on 142 articles"). Second person ("your feed set") for the operator.
  First person is avoided.
- **Casing:** Sentence case for prose and headlines. **UPPERCASE** is reserved
  for labels, eyebrows, badges, and buttons (Saira Condensed). Outlet names keep
  their own casing (POLITICO, NPR, The Hill).
- **Numbers & time:** Concrete and mono-set. "68–30 vote", "142 articles",
  "6:42 PM EDT", "last 24 hours", "every 15 minutes." Timestamps and counts
  always render in IBM Plex Mono.
- **Headlines:** Real newswire phrasing — "Senate advances defense package after
  late-night vote." No clickbait, no questions, no emoji.
- **Emoji:** **None.** Status is shown with colored dots/badges, not emoji.
- **Vibe:** Situation room. Eyebrows like "Live intelligence monitoring",
  section names like "Daily U.S./Iran rollup", "Field notes", "Social media
  watch floor."

---

## Visual foundations

**Palette.** Federal situation-room. Deep navy surfaces (`--navy-950 → 600`),
**political crimson** (`--crimson-500 #c8324a`) as the primary action/alert,
**federal blue** (`--federal-500 #2f6fbf`) for links and summaries, **brass/gold**
(`--brass-500 #c2a14f`) as the official-seal accent (eyebrows, focus rings),
and parchment (`--paper-50 #f6f3ea`) as the "white." Status: green (operational),
amber (6-hour window), red (breaking). See `tokens/colors.css`.

**Type.** `tokens/typography.css`.
- **Spectral** (serif) — headlines, rollup titles, and editorial/article body.
  Gives briefing-document gravitas.
- **Libre Franklin** (sans) — UI, body copy, dek lines. Campaign-grade.
- **Saira Condensed** — uppercase eyebrows, labels, button text (situation-room
  signage).
- **IBM Plex Mono** — timestamps, counts, data stamps.

**Background.** A signature fixed "war-room" backdrop (`tokens/base.css`):
a deep navy vertical gradient + a soft federal-blue vignette at top + a faint
brass glow + a 3px vertical "ledger pinstripe." `background-attachment: fixed`.
Not flat — but quiet enough to sit behind dense cards.

**Cards.** Large soft corners (`--radius-xl` 22px), a subtle top-lit gradient
fill, 1px hairline border, and a deep drop shadow (`--shadow-card`). An optional
colored **left accent rail** (4px) codes the section: crimson = alert/U.S.-Iran,
blue = summary, gold = official, green = status, amber = 6-hour. (This rail comes
straight from the source app's `.accent-card::before` — it is authentic, not a
generic AI trope.)

**Spacing & radii.** 4px base scale (`--space-1 … 16`). Radii: sm 10 / md 14 /
lg 18 / xl 22 / pill 999. See `tokens/spacing.css`.

**Motion.** Restrained. 0.15s `cubic-bezier(.22,.61,.36,1)` on hover/press only.
Hover = lift 1–2px + slightly brighter border (often brass) + faint tinted fill.
Press = subtle scale-down (0.98). No bounce, no looping/decorative animation.
A live clock ticks in the top bar.

**Borders & shadows.** Hairlines are translucent steel (`--line-soft/strong`);
the "active"/focus hairline shifts to translucent **brass**. Shadows are deep and
cool (war-room), not soft pastel. Inputs get a brass focus ring
(`0 0 0 3px rgba(194,161,79,.15)`).

**Imagery.** The product is data, not photography — there is no hero imagery.
Identity is carried by type, the backdrop, and the brass seal mark. Avoid
stock photos.

---

## Iconography

- **System:** **Lucide** (the source app imports `lucide-react`:
  `Newspaper`, `Radar`, `ScrollText`, `RefreshCcw`). This system uses **Lucide via
  CDN** (`https://unpkg.com/lucide`) in cards and the UI kit. Stroke icons,
  ~1.75–2px weight, sized 14–16px inline with labels.
- **No emoji** as UI. The single decorative glyph is a brass **★** in the seal
  lockup (a typographic mark, not an illustration).
- **No bespoke icon font or SVG sprite** shipped in the repo — Lucide is the
  source of truth. If you need an icon Lucide lacks, pick the nearest Lucide glyph
  and keep the stroke weight consistent.

---

## Index / manifest

**Root**
- `styles.css` — global entry point (consumers link this). `@import` lines only.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skills-compatible entry.

**`tokens/`** — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`,
`base.css` (resets + war-room backdrop).

**`guidelines/`** — foundation specimen cards (Design System tab): colors (navy,
crimson, federal, brass, status/text), type (serif, sans, labels/mono), spacing
(scale, radii/shadows), brand (wordmark, accent rails, backdrop).

**`components/`** — reusable React primitives (namespace
`window.ShrekMissionControlDesignSystem_4ccba0`):
- `core/` — **Button**, **Badge**, **Card** (+ `Card.Title`/`Card.Meta`), **NavTab**
- `news/` — **ArticleCard**, **SourceTile**, **SummaryPanel**
- `forms/` — **NotesField**
- `timeline/` — **TimelineEntry** (elapsed/countdown government-timeline row)

**`templates/mission-control/`** — reusable **Mission Control Dashboard** template
(`MissionControl.dc.html` + `ds-base.js`). A consuming project copies the folder;
edit one `base` line in `ds-base.js` to point at the bound design system, then edit
the markup directly. Mounts the DS components via `x-import`.

Each directory has a `*.card.html` demo (Components group) and each component a
`.d.ts` + `.prompt.md`.

**`ui_kits/mission-control/`** — interactive 3-view recreation
(`index.html` + `data.js` + `parts.jsx` + `screens.jsx`): Dashboard (24h rollup,
feed status, source grid), U.S./Iran board (daily + 6-hour rollups + field
notes), **Timelines** (live elapsed counts for active conflicts + countdowns to
midterms/elections/funding deadlines — uses `TimelineEntry`), and the Social watch
floor. Sample data is English-only; timeline dates are samples editable in `data.js`.

---

## Font substitution — please confirm

The source app shipped **system Arial** only. For the political redesign this
system adopts **Spectral, Libre Franklin, Saira Condensed, and IBM Plex Mono**
(loaded from Google Fonts CDN in `tokens/fonts.css`). If you have preferred or
licensed brand fonts, send them and I'll self-host and rewire the `@font-face`s.
