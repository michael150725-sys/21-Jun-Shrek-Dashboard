/* The three Mission Control screens. */

function DashboardScreen() {
  const { Card, Badge, SummaryPanel, SourceTile, Button } = window.ShrekMissionControlDesignSystem_4ccba0;
  const d = window.MC_DATA;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <section style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 18 }} className="mc-grid-main">
        <SummaryPanel
          eyebrow="24-hour rollup" title="U.S. politics & world events" rail="blue"
          status="Operational" basedOn={142} updated={d.updated}
          action={<Button size="sm" variant="secondary" icon={<Icon name="RefreshCcw" size={14} />}>Refresh</Button>}
        >
          {d.rollup24}
        </SummaryPanel>

        <Card rail="green" padding="var(--space-5)">
          <h2 style={{ font: "var(--type-h2)", color: "var(--text-primary)", margin: 0 }}>Feed status</h2>
          <p style={{ font: "var(--type-meta)", color: "var(--text-muted)", margin: "8px 0 16px", lineHeight: 1.5 }}>
            Server-side feed fetching keeps the browser clear of cross-site blocking. Non-English items are filtered out before they reach the board.
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <Badge tone="gold">142 articles · 24h</Badge>
              <Badge tone="blue">English only</Badge>
            </div>
            <div>
              <h3 style={{ font: "var(--type-h3)", color: "var(--text-primary)", margin: "0 0 6px" }}>Included sources</h3>
              <p style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", margin: 0, lineHeight: 1.5 }}>
                The Hill, ABC News, NBC News, NPR, Reuters, AP News, POLITICO.
              </p>
            </div>
            <div>
              <h3 style={{ font: "var(--type-h3)", color: "var(--text-primary)", margin: "0 0 6px" }}>Refresh cadence</h3>
              <p style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", margin: 0, lineHeight: 1.5 }}>
                Automatic refresh every 15 minutes. Use the button above to refresh immediately.
              </p>
            </div>
          </div>
        </Card>
      </section>

      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(290px, 1fr))", gap: 16 }}>
        {d.sources.map((s) => (
          <SourceTile key={s.id} source={s.name} homepage={s.homepage}
            items={s.items.map((it) => ({ ...it, source: s.name }))} />
        ))}
      </section>
    </div>
  );
}

function IranScreen() {
  const { Card, SummaryPanel, ArticleCard, NotesField, Button } = window.ShrekMissionControlDesignSystem_4ccba0;
  const d = window.MC_DATA;
  const [notes, setNotes] = React.useState("");
  React.useEffect(() => {
    const saved = window.localStorage.getItem("mc-kit-iran-notes");
    if (saved) setNotes(saved);
  }, []);
  const onChange = (e) => { setNotes(e.target.value); window.localStorage.setItem("mc-kit-iran-notes", e.target.value); };

  const dailyItems = [d.sources[2].items[0], d.sources[0].items[0]].map((it, i) => ({ ...it, source: i === 0 ? "Reuters" : "POLITICO" }));
  const sixItems = [d.sources[2].items[0]].map((it) => ({ ...it, source: "Reuters" }));

  return (
    <div style={{ display: "flex", gap: 18, alignItems: "stretch", flexWrap: "wrap" }} className="mc-iran-row">
      <div style={{ flex: 1, minWidth: 320, display: "flex", flexDirection: "column", gap: 18 }}>
        <SummaryPanel eyebrow="Daily rollup" title="U.S. / Iran" rail="crimson" basedOn={38} updated={d.updated}>
          {d.rollupIran24}
        </SummaryPanel>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {dailyItems.map((it, i) => <ArticleCard key={i} {...it} />)}
        </div>
        <SummaryPanel eyebrow="Last 6 hours" title="Latest movement" rail="amber" basedOn={6} updated={d.updated}>
          {d.rollupIran6}
        </SummaryPanel>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {sixItems.map((it, i) => <ArticleCard key={i} {...it} />)}
        </div>
      </div>

      <aside style={{ width: "min(420px, 100%)" }}>
        <Card rail="gold" padding="var(--space-5)">
          <h2 style={{ font: "var(--type-h2)", color: "var(--text-primary)", margin: "0 0 4px" }}>Field notes</h2>
          <NotesField hint="Local to this browser. Auto-saves as you type."
            value={notes} onChange={onChange} rows={12}
            placeholder="Track takeaways, timelines, players, claims to verify, and what feels like signal vs. noise." />
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12, gap: 10 }}>
            <Button size="sm" variant="secondary">Save notes now</Button>
            <Button size="sm" variant="danger" onClick={() => { setNotes(""); window.localStorage.removeItem("mc-kit-iran-notes"); }}>Clear notes</Button>
          </div>
        </Card>
      </aside>
    </div>
  );
}

function SocialScreen() {
  const { Card, Badge } = window.ShrekMissionControlDesignSystem_4ccba0;
  const d = window.MC_DATA;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <Card rail="crimson" padding="var(--space-5)">
        <p style={{ margin: "0 0 8px", font: "var(--font-label)", fontWeight: 600, fontSize: "0.74rem", letterSpacing: "var(--track-eyebrow)", textTransform: "uppercase", color: "var(--eyebrow)" }}>
          Launch pad
        </p>
        <h2 style={{ font: "var(--type-h2)", color: "var(--text-primary)", margin: 0 }}>Social media watch floor</h2>
        <p style={{ font: "var(--type-meta)", color: "var(--text-muted)", margin: "8px 0 0", lineHeight: 1.55, maxWidth: "78ch" }}>
          Official source accounts across X, Facebook, Instagram, YouTube, and TikTok. Real-time ingestion needs official APIs or a paid aggregator — this board keeps the launch links ready.
        </p>
      </Card>

      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 16 }}>
        {d.social.map((s) => (
          <Card key={s.id} padding="var(--space-4)" style={{ minHeight: 220, display: "flex", flexDirection: "column" }}>
            <a href={s.homepage} target="_blank" rel="noreferrer" style={{
              font: "var(--font-sans)", fontWeight: 800, fontSize: "1.15rem", color: "var(--federal-300)",
              textDecoration: "underline", textDecorationThickness: 2, textUnderlineOffset: 4,
            }}>
              {s.name} ↗
            </a>
            <p style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", margin: "10px 0 14px", lineHeight: 1.45, flex: 1 }}>{s.note}</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {s.platforms.map((p) => (
                <a key={p} href={s.homepage} target="_blank" rel="noreferrer" style={{
                  display: "flex", alignItems: "center", justifyContent: "center", minHeight: 44,
                  borderRadius: "var(--radius-md)", border: "1px solid var(--border)",
                  background: "rgba(255,255,255,0.03)", color: "var(--text-body)",
                  font: "var(--font-label)", fontWeight: 600, fontSize: "0.78rem", letterSpacing: "0.06em",
                  textTransform: "uppercase",
                }}>{p}</a>
              ))}
            </div>
          </Card>
        ))}
      </section>
    </div>
  );
}

function TimelinesScreen() {
  const { Card, TimelineEntry, Badge } = window.ShrekMissionControlDesignSystem_4ccba0;
  const d = window.MC_DATA;
  const DAY = 86400000;
  const now = Date.now();
  const fmt = (iso) => new Date(iso + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  const daysSince = (iso) => Math.max(0, Math.floor((now - new Date(iso + "T00:00:00").getTime()) / DAY));
  const daysUntil = (iso) => Math.max(0, Math.ceil((new Date(iso + "T00:00:00").getTime() - now) / DAY));

  const conflicts = d.timelines.conflicts.map((c) => ({ ...c, days: daysSince(c.start) }));
  const maxConf = Math.max(...conflicts.map((c) => c.days), 1);
  const counts = d.timelines.countdowns.map((c) => ({ ...c, days: daysUntil(c.target) }));
  const maxCount = Math.max(...counts.map((c) => c.days), 1);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <Card rail="gold" padding="var(--space-5)">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, flexWrap: "wrap" }}>
          <div>
            <p style={{ margin: "0 0 8px", font: "var(--font-label)", fontWeight: 600, fontSize: "0.74rem", letterSpacing: "var(--track-eyebrow)", textTransform: "uppercase", color: "var(--eyebrow)" }}>
              Government timelines
            </p>
            <h2 style={{ font: "var(--type-h2)", color: "var(--text-primary)", margin: 0 }}>How long, and how soon</h2>
            <p style={{ font: "var(--type-meta)", color: "var(--text-muted)", margin: "8px 0 0", maxWidth: "70ch", lineHeight: 1.55 }}>
              Live day counts for ongoing events and upcoming deadlines. Counts recompute against today&apos;s date.
            </p>
          </div>
          <Badge tone="neutral">Sample dates · editable</Badge>
        </div>
      </Card>

      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(360px, 1fr))", gap: 18 }}>
        <Card rail="crimson" padding="var(--space-5)">
          <h3 style={{ font: "var(--type-h3)", color: "var(--text-primary)", margin: "0 0 4px" }}>Active conflicts</h3>
          <p style={{ font: "var(--type-meta)", color: "var(--text-muted)", margin: "0 0 20px" }}>Elapsed duration</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
            {conflicts.map((c, i) => (
              <TimelineEntry key={i} label={c.label} detail={`${c.note} ${fmt(c.start)}`}
                value={c.days} mode="elapsed" pct={(c.days / maxConf) * 100} accent={c.accent}
                status={c.active === false ? "Ended" : "Active"} />
            ))}
          </div>
        </Card>

        <Card rail="blue" padding="var(--space-5)">
          <h3 style={{ font: "var(--type-h3)", color: "var(--text-primary)", margin: "0 0 4px" }}>Countdowns</h3>
          <p style={{ font: "var(--type-meta)", color: "var(--text-muted)", margin: "0 0 20px" }}>Time remaining</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
            {counts.map((c, i) => (
              <TimelineEntry key={i} label={c.label} detail={`${c.note} · ${fmt(c.target)}`}
                value={c.days} unit="days left" mode="countdown" pct={(c.days / maxCount) * 100} accent={c.accent} />
            ))}
          </div>
        </Card>
      </section>
    </div>
  );
}

Object.assign(window, { DashboardScreen, IranScreen, SocialScreen, TimelinesScreen });
