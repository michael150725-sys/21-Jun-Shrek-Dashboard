Action control with an uppercase situation-room label; use for refresh, save, and primary CTAs across Mission Control.

```jsx
<Button variant="primary" icon={<RefreshCcw size={15} />}>Refresh feed</Button>
<Button variant="secondary">Open source</Button>
<Button variant="gold">Mark briefed</Button>
<Button variant="danger">Clear notes</Button>
```

Variants: `primary` (crimson), `secondary` (navy outline), `gold` (brass/official), `ghost`, `danger`. Sizes: `sm` `md` `lg`. Pass Lucide nodes via `icon` / `iconRight`.
