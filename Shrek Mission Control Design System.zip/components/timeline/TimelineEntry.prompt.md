A single timeline row for the government-timeline board; stack several inside a `Card`. Compute day counts and bar `pct` upstream so the component stays deterministic.

```jsx
<TimelineEntry label="Russia–Ukraine war" detail="Ongoing since Feb 24, 2022"
  value={1578} unit="days" mode="elapsed" pct={100} accent="crimson" />
<TimelineEntry label="U.S. midterms" detail="Election Day · Nov 3, 2026"
  value={135} unit="days left" mode="countdown" pct={40} accent="blue" />
```

`mode="elapsed"` draws a solid bar (ongoing); `mode="countdown"` draws a striped bar (future). Scale `pct` against the largest value in each group so rows compare fairly.
