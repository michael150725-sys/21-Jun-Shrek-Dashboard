import React from "react";

export interface BadgeProps {
  children?: React.ReactNode;
  /** Status color. @default "gold" */
  tone?: "gold" | "blue" | "crimson" | "green" | "amber" | "neutral";
  /** Filled instead of tinted-outline. @default false */
  solid?: boolean;
  /** Show a leading status dot. @default false */
  dot?: boolean;
  icon?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Pill / count chip for article counts, feed status, and breaking flags.
 */
export function Badge(props: BadgeProps): JSX.Element;
