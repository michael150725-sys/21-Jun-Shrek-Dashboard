---
name: shrek-mission-control-design
description: Use this skill to generate well-branded interfaces and assets for Shrek's Mission Control (a political / situation-room news dashboard), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference
- **Global CSS:** link `styles.css` (pulls all tokens + the war-room backdrop).
- **Identity:** political / federal situation-room. Deep navy + political crimson + federal blue + brass/gold + parchment. Red, white & blue with an official-seal accent.
- **Type:** Spectral (serif headlines/body), Libre Franklin (UI sans), Saira Condensed (UPPERCASE labels/buttons), IBM Plex Mono (timestamps/counts).
- **Icons:** Lucide (stroke, 14–16px). No emoji in UI.
- **Components:** `window.ShrekMissionControlDesignSystem_4ccba0` → Button, Badge, Card, NavTab, ArticleCard, SourceTile, SummaryPanel, NotesField. Mount via `_ds_bundle.js`.
- **Cards:** large radius, deep shadow, optional colored left accent rail to code sections.
- **Content rule:** ENGLISH ONLY. Drop any non-English (e.g. Spanish) articles. Calm, declarative, briefing-desk voice; sentence case prose, UPPERCASE labels; concrete numbers/times in mono.
