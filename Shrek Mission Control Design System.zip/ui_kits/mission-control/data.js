/* Sample feed data for the Mission Control UI kit.
   All content is ENGLISH ONLY — the live app filters out
   non-English (e.g. Spanish) items upstream. */
window.MC_DATA = {
  updated: "6:45 PM EDT",
  rollup24:
    "The Senate advanced the defense authorization overnight on a bipartisan 68\u201330 vote, clearing the bill for a House conference next week. The White House briefed allies ahead of a regional security call, while House leaders scheduled an appropriations hearing before the recess. Markets steadied after the Treasury signaled no change to the auction calendar.",
  rollupIran24:
    "Diplomats described back-channel talks as \u201cexploratory but serious,\u201d with sanctions relief and inspection access the central sticking points. The State Department reiterated that deterrence posture is unchanged. Allied governments coordinated messaging ahead of tomorrow\u2019s security call.",
  rollupIran6:
    "A regional security call is being scheduled for the morning. Officials describe the agenda as deconfliction and deterrence. No new force-posture changes have been announced in the last six hours.",
  sources: [
    {
      id: "politico", name: "POLITICO", homepage: "https://www.politico.com",
      items: [
        { title: "Senate advances defense package after late-night vote", summary: "The 68\u201330 tally clears the bill for a House conference next week.", time: "6:42 PM EDT", breaking: true },
        { title: "Leadership eyes stopgap to avoid shutdown before recess", summary: "Appropriators float a short continuing resolution as talks stall.", time: "5:30 PM EDT" },
        { title: "Campaign committees post record second-quarter haul", summary: "Both parties report strong small-dollar momentum heading into summer.", time: "3:11 PM EDT" },
      ],
    },
    {
      id: "the-hill", name: "The Hill", homepage: "https://thehill.com",
      items: [
        { title: "House panel sets hearing on appropriations deadline", summary: "Chair signals a stopgap is on the table before the recess.", time: "4:05 PM EDT" },
        { title: "Bipartisan group unveils permitting compromise", summary: "The framework pairs transmission siting with review timelines.", time: "1:48 PM EDT" },
        { title: "Governors press Washington on disaster funding", summary: "A coalition warns the relief account could run dry by August.", time: "11:20 AM EDT" },
      ],
    },
    {
      id: "reuters", name: "Reuters", homepage: "https://www.reuters.com",
      items: [
        { title: "White House briefs allies ahead of regional security call", summary: "Officials describe the agenda as deconfliction and deterrence.", time: "5:18 PM EDT", breaking: true },
        { title: "Treasury holds auction calendar steady, easing markets", summary: "No change to issuance sizes despite rate-path speculation.", time: "2:55 PM EDT" },
      ],
    },
    {
      id: "ap-news", name: "AP News", homepage: "https://apnews.com",
      items: [
        { title: "Supreme Court clears final opinions of the term", summary: "Rulings on agency authority and elections close out the session.", time: "10:02 AM EDT" },
        { title: "Election officials brief on certification timelines", summary: "Briefing emphasizes routine procedures and security protocols.", time: "9:14 AM EDT" },
      ],
    },
    {
      id: "npr", name: "NPR", homepage: "https://www.npr.org",
      items: [
        { title: "Federal workforce survey shows hiring backlog easing", summary: "Agencies report shorter time-to-hire after process changes.", time: "12:36 PM EDT" },
        { title: "Inflation cools for a third straight month", summary: "Core readings track closer to the central bank\u2019s target.", time: "8:30 AM EDT" },
      ],
    },
    {
      id: "abc-news", name: "ABC News", homepage: "https://abcnews.go.com",
      items: [
        { title: "Border security funding talks resume on the Hill", summary: "Negotiators return to the table after a two-week pause.", time: "1:05 PM EDT" },
      ],
    },
  ],
  social: [
    { id: "politico", name: "POLITICO", homepage: "https://www.politico.com", note: "Fast political desk; strong on Congress and campaigns.", platforms: ["X", "Facebook", "Instagram", "YouTube"] },
    { id: "the-hill", name: "The Hill", homepage: "https://thehill.com", note: "Capitol Hill coverage and floor activity.", platforms: ["X", "Facebook", "Instagram", "YouTube"] },
    { id: "reuters", name: "Reuters", homepage: "https://www.reuters.com", note: "Global wire; reliable for breaking confirmations.", platforms: ["X", "Facebook", "Instagram", "YouTube", "TikTok"] },
    { id: "ap-news", name: "AP News", homepage: "https://apnews.com", note: "Wire service; primary-source standard.", platforms: ["X", "Facebook", "Instagram", "YouTube", "TikTok"] },
    { id: "npr", name: "NPR", homepage: "https://www.npr.org", note: "Public-radio newsroom; explainers and analysis.", platforms: ["X", "Facebook", "Instagram", "YouTube", "TikTok"] },
    { id: "nbc-news", name: "NBC News", homepage: "https://www.nbcnews.com", note: "Broadcast network desk; video-forward.", platforms: ["X", "Facebook", "Instagram", "YouTube", "TikTok"] },
  ],
  // Sample dates — edit these to track real events.
  timelines: {
    conflicts: [
      { label: "Russia\u2013Ukraine war", start: "2022-02-24", accent: "crimson", note: "Ongoing since", active: true },
      { label: "Israel\u2013Hamas war", start: "2023-10-07", accent: "amber", note: "Ongoing since", active: true },
      { label: "U.S.\u2013Iran war", start: "2026-02-28", accent: "gold", note: "Hostilities since", active: true },
    ],
    countdowns: [
      { label: "Supreme Court term ends", target: "2026-06-29", accent: "gold", note: "Final opinions" },
      { label: "Debt-ceiling X-date", target: "2026-08-01", accent: "crimson", note: "Borrowing limit reached" },
      { label: "Government funding deadline", target: "2026-09-30", accent: "amber", note: "Funding lapses" },
      { label: "Next Supreme Court term opens", target: "2026-10-05", accent: "blue", note: "First Monday" },
      { label: "U.S. midterm elections", target: "2026-11-03", accent: "blue", note: "Election Day" },
      { label: "Next presidential election", target: "2028-11-07", accent: "green", note: "Election Day" },
    ],
  },
};
