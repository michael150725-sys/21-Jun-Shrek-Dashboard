import React from "react";

export interface TimelineEntryProps {
  /** Event name, e.g. "Russia–Ukraine war". */
  label: string;
  /** Date / context line, e.g. "Ongoing since Feb 24, 2022". */
  detail?: string;
  /** The headline figure (usually a day count). */
  value: number | string;
  /** Unit label. Defaults to "days" (elapsed) / "days left" (countdown). */
  unit?: string;
  /** "elapsed" = ongoing (solid bar) · "countdown" = future (striped bar). @default "elapsed" */
  mode?: "elapsed" | "countdown";
  /** Track fill 0–100, scaled by the consumer relative to the group. @default 100 */
  pct?: number;
  /** Bar / figure color. @default "crimson" */
  accent?: "crimson" | "amber" | "blue" | "gold" | "green";
  /** Optional status marker beside the label (e.g. "Active") with a colored dot. */
  status?: string;
  style?: React.CSSProperties;
}

/**
 * One row of a government-timeline board: label, date detail, big day count, progress track.
 * @startingPoint section="Timeline" subtitle="Elapsed / countdown timeline row" viewport="700x110"
 */
export function TimelineEntry(props: TimelineEntryProps): JSX.Element;
