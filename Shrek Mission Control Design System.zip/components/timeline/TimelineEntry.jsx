import React from "react";

const ACCENTS = {
  crimson: "var(--crimson-500)",
  amber: "var(--status-amber)",
  blue: "var(--federal-500)",
  gold: "var(--brass-500)",
  green: "var(--status-green)",
};

/**
 * TimelineEntry — one row in a government-timeline board. Shows a label,
 * a date/context detail, a big mono figure (days), and a thin progress
 * track. Use mode="elapsed" for ongoing events (bar grows) and
 * mode="countdown" for future dates (bar shows time remaining).
 * Deterministic: pass the computed value + pct; compute dates upstream.
 */
export function TimelineEntry({ label, detail, value, unit, mode = "elapsed", pct = 100, accent = "crimson", status, style }) {
  const color = ACCENTS[accent] || ACCENTS.crimson;
  const width = Math.max(2, Math.min(100, pct));
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 9, ...style }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 14 }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 9, flexWrap: "wrap" }}>
            <span style={{ font: "var(--type-h3)", fontSize: "1.04rem", color: "var(--text-primary)", lineHeight: 1.25 }}>
              {label}
            </span>
            {status && (
              <span style={{
                display: "inline-flex", alignItems: "center", gap: 5,
                font: "var(--font-label)", fontWeight: 600, fontSize: "0.62rem",
                letterSpacing: "0.12em", textTransform: "uppercase", color,
              }}>
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: color, boxShadow: `0 0 0 3px color-mix(in srgb, ${color} 22%, transparent)` }} />
                {status}
              </span>
            )}
          </div>
          {detail && (
            <div style={{ font: "var(--type-mono-sm)", color: "var(--text-faint)", marginTop: 4, letterSpacing: "0.02em" }}>
              {detail}
            </div>
          )}
        </div>
        <div style={{ textAlign: "right", flex: "none", display: "flex", alignItems: "baseline", gap: 6 }}>
          <span style={{ font: "var(--font-mono)", fontWeight: 600, fontSize: "1.5rem", color, letterSpacing: "0.01em" }}>
            {typeof value === "number" ? value.toLocaleString() : value}
          </span>
          <span style={{ font: "var(--font-label)", fontWeight: 600, fontSize: "0.72rem", letterSpacing: "var(--track-label)", textTransform: "uppercase", color: "var(--text-muted)" }}>
            {unit || (mode === "countdown" ? "days left" : "days")}
          </span>
        </div>
      </div>
      <div style={{ height: 6, borderRadius: "var(--radius-pill)", background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
        <div style={{
          height: "100%", width: `${width}%`,
          borderRadius: "var(--radius-pill)",
          background: mode === "countdown"
            ? `repeating-linear-gradient(90deg, ${color} 0 7px, rgba(255,255,255,0.18) 7px 9px)`
            : color,
          opacity: mode === "countdown" ? 0.85 : 1,
        }} />
      </div>
    </div>
  );
}
