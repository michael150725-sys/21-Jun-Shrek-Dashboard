import React from "react";

/**
 * Button — primary action control for Mission Control.
 * Federal/situation-room styling: crimson primary, navy outline,
 * brass for "official" actions, ghost for low emphasis.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  icon = null,
  iconRight = null,
  disabled = false,
  type = "button",
  onClick,
  style,
  ...rest
}) {
  const sizes = {
    sm: { padding: "7px 12px", font: "var(--type-label)", letterSpacing: "var(--track-label)", gap: 6, radius: "var(--radius-sm)" },
    md: { padding: "10px 16px", font: "var(--type-label)", letterSpacing: "var(--track-label)", gap: 8, radius: "var(--radius-md)" },
    lg: { padding: "13px 22px", font: "var(--type-label)", letterSpacing: "var(--track-label)", gap: 9, radius: "var(--radius-md)" },
  }[size];

  const variants = {
    primary: { background: "var(--crimson-500)", color: "var(--text-on-crimson)", border: "1px solid var(--crimson-400)" },
    secondary: { background: "rgba(47,111,191,0.10)", color: "var(--text-primary)", border: "1px solid var(--line-strong)" },
    gold: { background: "var(--brass-500)", color: "var(--text-on-brass)", border: "1px solid var(--brass-400)" },
    ghost: { background: "transparent", color: "var(--text-body)", border: "1px solid transparent" },
    danger: { background: "rgba(225,80,104,0.12)", color: "var(--crimson-300)", border: "1px solid rgba(225,80,104,0.35)" },
  }[variant];

  const fontSize = size === "lg" ? "0.92rem" : size === "sm" ? "0.78rem" : "0.84rem";

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: sizes.gap,
        padding: sizes.padding,
        borderRadius: sizes.radius,
        font: "var(--font-label)",
        fontWeight: 600,
        fontSize,
        letterSpacing: sizes.letterSpacing,
        textTransform: "uppercase",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.45 : 1,
        whiteSpace: "nowrap",
        transition: "transform var(--dur-fast) var(--ease), filter var(--dur-fast) var(--ease), border-color var(--dur-fast) var(--ease)",
        ...variants,
        ...style,
      }}
      onMouseEnter={(e) => { if (!disabled) { e.currentTarget.style.transform = "translateY(-1px)"; e.currentTarget.style.filter = "brightness(1.08)"; } }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = "none"; e.currentTarget.style.filter = "none"; }}
      onMouseDown={(e) => { if (!disabled) e.currentTarget.style.transform = "translateY(0) scale(0.98)"; }}
      onMouseUp={(e) => { if (!disabled) e.currentTarget.style.transform = "translateY(-1px)"; }}
      {...rest}
    >
      {icon}
      {children}
      {iconRight}
    </button>
  );
}
