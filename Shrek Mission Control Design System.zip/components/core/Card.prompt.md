The primary content panel; use a colored `rail` to code a card to a section (crimson = alert, blue = summary, gold = official, green = status, amber = 6-hour window).

```jsx
<Card rail="blue">
  <Card.Title>24-hour rollup</Card.Title>
  <Card.Meta>Major U.S. politics & world developments.</Card.Meta>
  {/* body */}
</Card>
```

Slots: `Card.Title` (Spectral serif), `Card.Meta` (muted sub-line).
