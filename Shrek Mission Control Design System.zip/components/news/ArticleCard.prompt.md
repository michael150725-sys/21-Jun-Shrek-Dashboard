A single clickable feed item; pair with `breaking` for crimson-flagged top stories.

```jsx
<ArticleCard
  title="Senate advances defense package after late-night vote"
  summary="The 68–30 tally clears the bill for a House conference next week."
  source="POLITICO" time="6:42 PM EDT" breaking
/>
```

All content should be English — the feed filter drops non-English items upstream.
