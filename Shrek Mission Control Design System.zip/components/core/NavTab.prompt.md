Top-bar pill navigation; mark the current view `active` for the crimson highlight.

```jsx
<NavTab icon={<Newspaper size={15} />} active>Dashboard</NavTab>
<NavTab icon={<Radar size={15} />} href="/iran">U.S./Iran</NavTab>
<NavTab icon={<ScrollText size={15} />} href="/social">Social</NavTab>
```
