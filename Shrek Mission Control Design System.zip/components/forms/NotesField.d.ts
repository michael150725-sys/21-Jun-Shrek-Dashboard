import React from "react";

export interface NotesFieldProps {
  /** Uppercase field label. */
  label?: string;
  /** Helper line under the label. */
  hint?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  placeholder?: string;
  /** @default 8 */
  rows?: number;
  style?: React.CSSProperties;
}

/** Themed multi-line notes input with brass focus ring (field-notes panel). */
export function NotesField(props: NotesFieldProps): JSX.Element;
