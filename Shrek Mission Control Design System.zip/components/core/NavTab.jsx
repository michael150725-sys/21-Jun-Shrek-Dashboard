import React from "react";

/**
 * NavTab — pill navigation item used in the top bar.
 * Mirrors the source ".nav a" but adds an active state with a
 * brass underglow for the current view.
 */
export function NavTab({ children, icon = null, active = false, href = "#", onClick, style, ...rest }) {
  return (
    <a
      href={href}
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        padding: "10px 16px",
        borderRadius: "var(--radius-pill)",
        font: "var(--font-label)",
        fontWeight: 600,
        fontSize: "0.82rem",
        letterSpacing: "var(--track-label)",
        textTransform: "uppercase",
        color: active ? "var(--paper-50)" : "var(--text-body)",
        background: active ? "rgba(225,80,104,0.16)" : "rgba(47,111,191,0.07)",
        border: active ? "1px solid rgba(225,80,104,0.45)" : "1px solid var(--border)",
        boxShadow: active ? "0 4px 16px rgba(225,80,104,0.20)" : "none",
        cursor: "pointer",
        transition: "border-color var(--dur-fast) var(--ease), transform var(--dur-fast) var(--ease), background var(--dur-fast) var(--ease)",
        ...style,
      }}
      onMouseEnter={(e) => {
        if (!active) {
          e.currentTarget.style.borderColor = "rgba(47,111,191,0.45)";
          e.currentTarget.style.transform = "translateY(-1px)";
          e.currentTarget.style.background = "rgba(47,111,191,0.14)";
        }
      }}
      onMouseLeave={(e) => {
        if (!active) {
          e.currentTarget.style.borderColor = "var(--border)";
          e.currentTarget.style.transform = "none";
          e.currentTarget.style.background = "rgba(47,111,191,0.07)";
        }
      }}
      {...rest}
    >
      {icon}
      {children}
    </a>
  );
}
