import React from "react";

export interface SummaryPanelProps {
  /** Small uppercase brass label. @default "Briefing" */
  eyebrow?: string;
  title: string;
  /** Accent rail color. @default "blue" */
  rail?: "crimson" | "blue" | "gold" | "green" | "amber" | "none";
  /** Article count the rollup was built from. */
  basedOn?: number;
  /** Last-updated stamp string. */
  updated?: string;
  /** Optional status badge text, e.g. "Operational". */
  status?: string;
  /** Optional action node (e.g. a refresh Button) in the header. */
  action?: React.ReactNode;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Rollup / briefing panel with eyebrow, serif title, prose, footer stamp.
 * @startingPoint section="News" subtitle="Rollup / briefing panel" viewport="700x300"
 */
export function SummaryPanel(props: SummaryPanelProps): JSX.Element;
