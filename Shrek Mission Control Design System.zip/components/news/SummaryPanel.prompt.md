The flagship rollup/briefing panel; put the summary prose in children and the refresh control in `action`.

```jsx
<SummaryPanel
  eyebrow="24-hour rollup" title="U.S. politics & world events"
  rail="blue" status="Operational" basedOn={142} updated="6:45 PM EDT"
  action={<Button size="sm" variant="secondary" icon={<RefreshCcw size={14} />}>Refresh</Button>}
>
  The Senate advanced the defense package overnight…
</SummaryPanel>
```
