import React from "react";

export interface NavTabProps {
  children?: React.ReactNode;
  icon?: React.ReactNode;
  /** Highlights as the current view. @default false */
  active?: boolean;
  href?: string;
  onClick?: (e: React.MouseEvent<HTMLAnchorElement>) => void;
  style?: React.CSSProperties;
}

/** Pill navigation item for the Mission Control top bar. */
export function NavTab(props: NavTabProps): JSX.Element;
