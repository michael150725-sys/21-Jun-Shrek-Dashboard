Compact pill for counts and feed status; use a status dot for live/operational state.

```jsx
<Badge tone="green" dot>Operational</Badge>
<Badge tone="gold">142 articles · 24h</Badge>
<Badge tone="crimson" solid dot>Breaking</Badge>
```

Tones: `gold` `blue` `crimson` `green` `amber` `neutral`. `solid` fills it; `dot` adds a status dot.
