import React from "react";
import { Card } from "../core/Card.jsx";
import { Badge } from "../core/Badge.jsx";

/**
 * SummaryPanel — the rollup / briefing panel. Eyebrow label, serif
 * title, a body block of prose, and a footer line with source count
 * and last-updated stamp.
 */
export function SummaryPanel({
  eyebrow = "Briefing",
  title,
  rail = "blue",
  basedOn,
  updated,
  status,
  action = null,
  children,
  style,
}) {
  return (
    <Card rail={rail} padding="var(--space-5)" style={style}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, marginBottom: 12 }}>
        <div>
          <p style={{
            font: "var(--font-label)", fontWeight: 600, fontSize: "0.74rem",
            letterSpacing: "var(--track-eyebrow)", textTransform: "uppercase",
            color: "var(--eyebrow)", margin: "0 0 8px",
          }}>
            {eyebrow}
          </p>
          <h2 style={{ font: "var(--type-h2)", color: "var(--text-primary)", margin: 0 }}>{title}</h2>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, flex: "none" }}>
          {status && <Badge tone="green" dot>{status}</Badge>}
          {action}
        </div>
      </div>

      <div style={{
        font: "var(--type-read)", color: "var(--text-body)",
        lineHeight: 1.62, whiteSpace: "pre-wrap", minHeight: 120,
      }}>
        {children}
      </div>

      {(basedOn != null || updated) && (
        <p style={{
          font: "var(--type-mono-sm)", color: "var(--text-faint)",
          margin: "14px 0 0", letterSpacing: "0.02em",
        }}>
          {basedOn != null ? `Based on ${basedOn} articles` : ""}
          {basedOn != null && updated ? "   ·   " : ""}
          {updated ? `Updated ${updated}` : ""}
        </p>
      )}
    </Card>
  );
}
